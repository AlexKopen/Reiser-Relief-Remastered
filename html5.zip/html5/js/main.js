document.addEventListener('DOMContentLoaded', function () {
    var path = window.location.pathname.replace(/\//g, '').trim().toLowerCase();
    switch (path) {
        case '':
            newsletterSignup();
            break;
        case 'about':
            break;
        case 'contact':
            contactSubmit();
            break;
    }
});
function newsletterSignup() {
    var submitButton = document.getElementById('submit-button');
    submitButton.addEventListener('click', function () {
        var topText = document.getElementById('nl-top-text');
        var form = document.getElementById('newsletter-form');
        var name = document.getElementById('nl-name-field');
        var email = document.getElementById('nl-email-field');
        var error = document.getElementById('nl-error-text');
        var success = document.getElementById('nl-success-text');
        var emailFormatted = email.value.trim();
        var nameFormatted = name.value.trim().split(' ');
        var firstName = nameFormatted[0];
        var lastName = nameFormatted[1];
        var formData = new FormData();
        formData.append('fname', firstName);
        formData.append('lname', lastName);
        formData.append('email', emailFormatted);
        fetch("/wp-json/v1/subscribe", {
            body: formData,
            method: "post"
        }).then(function (response) {
            if (response.ok) {
                topText.style.display = 'none';
                form.style.display = 'none';
                success.style.display = 'block';
                error.style.display = 'none';
            }
        });
    });
}
function contactSubmit() {
    var submitButton = document.getElementById('submit-button');
    submitButton.addEventListener('click', function () {
        var form = document.getElementById('contact-form');
        var name = document.getElementById('contact-name-field');
        var email = document.getElementById('contact-email-field');
        var subject = document.getElementById('contact-subject-field');
        var message = document.getElementById('contact-message-field');
        var success = document.getElementById('contact-success');
        var emailFormatted = email.value.trim();
        var formData = new FormData();
        formData.append('name', name.value);
        formData.append('email', emailFormatted);
        formData.append('subject', subject.value);
        formData.append('message', message.value);
        fetch("/wp-json/v1/contact", {
            body: formData,
            method: "post"
        }).then(function (response) {
            if (response.ok) {
                form.style.display = 'none';
                success.style.display = 'flex';
            }
        });
    });
}
